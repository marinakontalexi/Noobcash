Python3.6 is recommended


Anaconda's Python distribution contains all the dependencies needed



import modules needed if you do not use Anaconda env



You can user REST API or just messages via threads or processes for the nodes.
Install flask using pip install Flask if you choose REST



Keep in mind that this is just a scaffold. One can write the code and the modules differently to achieve the same result.
Key factors, elements, functions and classes are missing and one shall decide on his own which elements to add or not.

